# SiftNodes Discord Bot - Python edition
# Owner ID: 1520903362667876523
import os, json, asyncio
from pathlib import Path
import discord
from discord.ext import commands
from dotenv import load_dotenv
import aiohttp

load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN', 'Siftnodes_ka_token_here').strip()
OWNER_ID = 1520903362667876523
PREFIX = os.getenv('PREFIX', '!')
BOT_NAME = 'SiftNodes'
FOOTER = 'SiftNodes • Premium Hosting'
DATA = Path('data'); DATA.mkdir(exist_ok=True)
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix=PREFIX, intents=intents, help_command=None)
history = {}

def load_db(name, default):
    p = DATA / f'{name}.json'
    try: return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default
    except Exception: return default

def save_db(name, value):
    (DATA / f'{name}.json').write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')

def embed(title, description='', color=0x5865F2):
    e = discord.Embed(title=title, description=description, color=color)
    e.set_footer(text=FOOTER)
    return e

def owner_only():
    async def predicate(ctx):
        if ctx.author.id != OWNER_ID:
            raise commands.CheckFailure('This command is restricted to the bot owner.')
        return True
    return commands.check(predicate)

@bot.event
async def on_ready():
    print(f'{BOT_NAME} logged in as {bot.user} | Owner ID: {OWNER_ID}')
    await bot.change_presence(activity=discord.Game(name='SiftNodes Hosting'))

@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CommandNotFound): return
    if isinstance(error, commands.CheckFailure):
        await ctx.reply(embed=embed('🔒 Permission denied', str(error), 0xED4245), mention_author=False); return
    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.reply(embed=embed('Missing argument', f'Usage: `{PREFIX}{ctx.command} {ctx.command.signature}`', 0xFEE75C), mention_author=False); return
    print('Command error:', repr(error))
    await ctx.reply(embed=embed('Error', 'Command failed. Check the bot console for details.', 0xED4245), mention_author=False)

@bot.command(name='help')
async def help_cmd(ctx):
    e = embed('🌐 SiftNodes — Hosting Bot',
      f'Prefix: `{PREFIX}`\n\n**General**\n`{PREFIX}help` — Show commands\n`{PREFIX}whoami` — Show your user ID\n`{PREFIX}ai <question>` — Ask the AI\n`{PREFIX}plan-list` — List plans\n`{PREFIX}promo-list` — List promo codes\n`{PREFIX}review <stars> <text>` — Submit a review\n\n**Admin**\n`{PREFIX}plan-add <name> <price> <details>`\n`{PREFIX}plan-remove <name>`\n`{PREFIX}promo-create <code> <discount>`\n`{PREFIX}promo-remove <code>`\n`{PREFIX}announcement <message>`\n`{PREFIX}clear <amount>`\n`{PREFIX}lock` / `{PREFIX}unlock`\n\n**Owner**\n`{PREFIX}ownerinfo`')
    await ctx.reply(embed=e, mention_author=False)

@bot.command()
async def whoami(ctx):
    await ctx.reply(embed=embed('Your Discord ID', f'`{ctx.author.id}`'), mention_author=False)

@bot.command(name='ownerinfo')
@owner_only()
async def ownerinfo(ctx):
    await ctx.reply(embed=embed('SiftNodes Owner', f'Owner ID: `{OWNER_ID}`'), mention_author=False)

@bot.command(name='ai')
async def ai_cmd(ctx, *, question: str):
    uid = str(ctx.author.id)
    history.setdefault(uid, [])
    history[uid].append({'role':'user','content':question})
    history[uid] = history[uid][-10:]
    messages = [{'role':'system','content':'You are SiftNodes, a friendly helpful Discord hosting assistant. Reply naturally in Hindi, English, or Hinglish. Keep answers concise.'}] + history[uid]
    async with ctx.typing():
        try:
            timeout = aiohttp.ClientTimeout(total=45)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.post('https://text.pollinations.ai/openai', json={'model':'openai','messages':messages,'temperature':0.7,'max_tokens':800,'stream':False,'private':True}) as r:
                    if r.status != 200: raise RuntimeError(f'AI service returned HTTP {r.status}')
                    data = await r.json(content_type=None)
            answer = data['choices'][0]['message']['content'].strip()
            history[uid].append({'role':'assistant','content':answer})
            for i in range(0, len(answer), 1900):
                await ctx.reply(answer[i:i+1900], mention_author=False)
        except Exception as ex:
            print('AI error:', repr(ex))
            await ctx.reply(embed=embed('AI unavailable', 'AI service did not respond. Please try again later.', 0xED4245), mention_author=False)

@bot.command(name='plan-add')
@commands.has_permissions(administrator=True)
async def plan_add(ctx, name: str, price: str, *, details: str):
    plans = load_db('plans', {})
    plans[name.lower()] = {'name':name, 'price':price, 'details':details}
    save_db('plans', plans)
    await ctx.reply(embed=embed('✅ Plan added', f'**{name}** — {price}\n{details}', 0x57F287), mention_author=False)

@bot.command(name='plan-remove')
@commands.has_permissions(administrator=True)
async def plan_remove(ctx, *, name: str):
    plans = load_db('plans', {})
    if plans.pop(name.lower(), None) is None:
        await ctx.reply(embed=embed('Not found', f'No plan named `{name}`.'), mention_author=False); return
    save_db('plans', plans)
    await ctx.reply(embed=embed('✅ Plan removed', name, 0x57F287), mention_author=False)

@bot.command(name='plan-list')
async def plan_list(ctx):
    plans = load_db('plans', {})
    desc = '\n'.join(f'**{p.get("name", k)}** — {p.get("price", "N/A")}\n{p.get("details", "")}' for k,p in plans.items()) or 'No plans configured yet. An administrator can add one with `!plan-add`.'
    await ctx.reply(embed=embed('📦 SiftNodes Plans', desc), mention_author=False)

@bot.command(name='promo-create')
@commands.has_permissions(administrator=True)
async def promo_create(ctx, code: str, discount: int):
    if not 1 <= discount <= 100:
        await ctx.reply('Discount must be between 1 and 100.', mention_author=False); return
    promos = load_db('promos', {})
    promos[code.upper()] = discount; save_db('promos', promos)
    await ctx.reply(embed=embed('✅ Promo created', f'`{code.upper()}` — {discount}% off', 0x57F287), mention_author=False)

@bot.command(name='promo-remove')
@commands.has_permissions(administrator=True)
async def promo_remove(ctx, code: str):
    promos = load_db('promos', {})
    if promos.pop(code.upper(), None) is None:
        await ctx.reply(embed=embed('Not found', f'Promo `{code}` does not exist.'), mention_author=False); return
    save_db('promos', promos)
    await ctx.reply(embed=embed('✅ Promo removed', code.upper(), 0x57F287), mention_author=False)

@bot.command(name='promo-list')
async def promo_list(ctx):
    promos = load_db('promos', {})
    desc = '\n'.join(f'`{c}` — {d}% off' for c,d in promos.items()) or 'No promo codes available.'
    await ctx.reply(embed=embed('🎟️ Promo Codes', desc), mention_author=False)

@bot.command()
@commands.has_permissions(administrator=True)
async def announcement(ctx, *, message: str):
    await ctx.channel.send(embed=embed('📢 SiftNodes Announcement', message, 0xFFD700))

@bot.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    amount = max(1, min(amount, 100))
    deleted = await ctx.channel.purge(limit=amount + 1)
    await ctx.send(embed=embed('🧹 Messages cleared', f'Deleted {len(deleted)-1} messages.'), delete_after=5)

@bot.command()
@commands.has_permissions(manage_channels=True)
async def lock(ctx):
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=False)
    await ctx.reply(embed=embed('🔒 Channel locked', 'Members can no longer send messages here.'), mention_author=False)

@bot.command()
@commands.has_permissions(manage_channels=True)
async def unlock(ctx):
    await ctx.channel.set_permissions(ctx.guild.default_role, send_messages=True)
    await ctx.reply(embed=embed('🔓 Channel unlocked', 'Members can send messages here again.'), mention_author=False)

@bot.command()
async def review(ctx, stars: int, *, text: str):
    if stars < 1 or stars > 5:
        await ctx.reply('Stars must be from 1 to 5.', mention_author=False); return
    reviews = load_db('reviews', [])
    reviews.append({'user':str(ctx.author), 'user_id':ctx.author.id, 'stars':stars, 'text':text})
    save_db('reviews', reviews)
    await ctx.reply(embed=embed('⭐ Review submitted', f'**Rating:** {"⭐"*stars}\n**Review:** {text}\n**By:** {ctx.author.mention}', 0xFFD700), mention_author=False)

@bot.event
async def on_member_join(member):
    # Optional welcome channel: set WELCOME_CHANNEL_ID in the environment.
    try:
        channel_id = int(os.getenv('WELCOME_CHANNEL_ID', '0'))
        channel = member.guild.get_channel(channel_id) if channel_id else None
        if channel: await channel.send(embed=embed('👋 Welcome to SiftNodes!', f'{member.mention}, welcome to **{member.guild.name}**!'))
    except Exception as e: print('Welcome error:', repr(e))

if TOKEN in ('', 'Siftnodes_ka_token_here'):
    print('ERROR: Set DISCORD_TOKEN in .env before starting the bot.')
else:
    bot.run(TOKEN)
