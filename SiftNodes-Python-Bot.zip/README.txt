SiftNodes Python Discord Bot

1. In the hosting panel, select Python 3.10+ (recommended 3.11).
2. Install packages: pip install -r requirements.txt
3. Put your Discord bot token in .env by replacing Siftnodes_ka_token_here.
4. Start command: python bot.py
5. Enable Message Content Intent and Server Members Intent in Discord Developer Portal.

Owner ID is configured as 1520903362667876523.

Important: this is a Python rewrite of core functions, not a one-to-one port of every original JavaScript feature. Ticket panels, payment QR workflows, screenshot verification, giveaways, Minecraft management, and some original admin/owner systems still need porting. Payment proof must be manually reviewed; do not auto-approve payments based only on AI screenshot checks.
